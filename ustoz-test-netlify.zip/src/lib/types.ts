// Umumiy tiplar (client va server uchun)

export interface SessionUser {
  id: string
  name: string
  login: string
  role: 'TEACHER' | 'STUDENT'
  points: number
  money: number
  levelOrder: number
}

export interface LevelInfo {
  id: string
  order: number
  name: string
  requiredPoints: number
  icon: string
}

export interface ModuleTreeTopic {
  id: string
  title: string
  isCovered: boolean
  questionCount: number
}

export interface ModuleTree {
  id: string
  title: string
  order: number
  topics: ModuleTreeTopic[]
}

export interface QuestionView {
  id: string
  topicId: string
  topicTitle?: string
  text: string
  optionA: string
  optionB: string
  optionC: string
  optionD: string
  correct?: string // faqat usto qaytariladi
}

export interface ShopItemView {
  id: string
  name: string
  icon: string
  price: number
  minLevel: number
  requiredForLevel: number
}

export interface StudentRow {
  id: string
  name: string
  login: string
  points: number
  money: number
  levelOrder: number
  levelName: string
  testsTaken: number
  avgPercent: number
}

export interface MonitorAnswerCell {
  sessionQuestionId: string
  selected: string
  isCorrect: boolean | null // null = javob berilmagan
}

export interface MonitorRow {
  attemptId: string
  userId: string
  name: string
  status: string
  answered: number
  score: number
  percent: number
  moneyEarned: number
  pointsEarned: number
  cells: MonitorAnswerCell[]
}

export interface MonitorQuestion {
  id: string
  order: number
  text: string
  correct: string
  correctCount: number
  wrongCount: number
}

export interface MonitorData {
  session: {
    id: string
    status: string
    questionCount: number
    createdAt: string
    finishedAt: string | null
    topicTitles: string[]
  }
  questions: MonitorQuestion[]
  rows: MonitorRow[]
}

export interface SessionBrief {
  id: string
  type: 'GROUP' | 'INDIVIDUAL'
  status: 'ACTIVE' | 'FINISHED'
  questionCount: number
  createdAt: string
  topicTitles: string[]
  attemptCount: number
  myAttemptId?: string | null
  myAttemptStatus?: string | null
}

export interface AttemptQuestion {
  id: string // sessionQuestion id
  order: number
  text: string
  optionA: string
  optionB: string
  optionC: string
  optionD: string
}

export interface AttemptState {
  attemptId: string
  status: string
  sessionId: string
  sessionType: 'GROUP' | 'INDIVIDUAL'
  sessionStatus: 'ACTIVE' | 'FINISHED'
  questions: AttemptQuestion[]
  answered: Record<string, { selected: string; isCorrect: boolean }>
}

export interface AttemptSummary {
  correct: number
  total: number
  moneyEarned: number
  pointsEarned: number
  levelUp: { from: string; to: string } | null
  newLevel: { name: string; order: number; icon: string }
}

export interface MeResponse {
  user: SessionUser
  level: LevelInfo | null
  nextLevel: LevelInfo | null
  ownedItemIds: string[]
  nextRequired: { item: ShopItemView; owned: boolean }[]
  nextRequiredOwnedCount: number
  canLevelUpNow: boolean
}

export interface SettingsValues {
  pointsPerCorrectGroup: number
  moneyPerCorrectGroup: number
  moneyPerCorrectIndividual: number
  totalModules: number
  modulesPerLevel: number
  avgPointsPerModule: number
}

export interface LevelsResponse {
  levels: LevelInfo[]
  settings: SettingsValues
}

export interface HistoryRow {
  id: string
  type: 'GROUP' | 'INDIVIDUAL'
  date: string
  correct: number
  total: number
  percent: number
  moneyEarned: number
  pointsEarned: number
}

export interface LeaderRow {
  id: string
  name: string
  points: number
  money: number
  levelOrder: number
  levelName: string
}

export interface ShopResponse {
  money: number
  levelOrder: number
  items: ShopItemView[]
  ownedItemIds: string[]
  nextLevel: LevelInfo | null
  nextRequired: { item: ShopItemView; owned: boolean }[]
}

export interface OverviewResponse {
  studentCount: number
  moduleCount: number
  topicCount: number
  coveredTopicCount: number
  questionCount: number
  groupSessionCount: number
  attemptCount: number
  avgPercent: number
  topStudents: LeaderRow[]
  recentSessions: { id: string; date: string; questionCount: number; participants: number; avgPercent: number; status: string }[]
}
