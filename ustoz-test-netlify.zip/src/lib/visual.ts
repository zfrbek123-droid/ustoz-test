'use client'

// Daraja ikonkalari (lucide) va boshqa vizual yordamchilar
import { Sprout, BookOpen, Lightbulb, Medal, GraduationCap, Crown, type LucideIcon } from 'lucide-react'

export { Sprout }

export const LEVEL_ICONS: Record<string, LucideIcon> = {
  sprout: Sprout,
  book: BookOpen,
  bulb: Lightbulb,
  medal: Medal,
  cap: GraduationCap,
  crown: Crown,
}

export function levelIcon(icon: string): LucideIcon {
  return LEVEL_ICONS[icon] ?? Sprout
}

// Ikonka ma'lum bo'lmaganda daraja tartib raqami bo'yicha standart ikonka
export const ORDER_ICONS = ['sprout', 'book', 'bulb', 'medal', 'cap', 'crown']

export function iconForOrder(order: number): string {
  return ORDER_ICONS[Math.min(order, ORDER_ICONS.length) - 1] ?? 'sprout'
}

// Sanani bir xil ko'rinishda formatlash: 03.11.2026 16:05
export function fmtDate(iso: string): string {
  const d = new Date(iso)
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`
}

export const LEVEL_COLORS = [
  'bg-stone-100 text-stone-700 border-stone-300', // 1 Yangi boshlovchi
  'bg-emerald-50 text-emerald-700 border-emerald-200', // 2 Shogird
  'bg-teal-50 text-teal-700 border-teal-200', // 3 Bilimdon
  'bg-amber-50 text-amber-700 border-amber-200', // 4 Ekspert
  'bg-orange-50 text-orange-700 border-orange-200', // 5 Ustoz
  'bg-rose-50 text-rose-700 border-rose-200', // 6 Legenda
]

export function levelColor(order: number): string {
  return LEVEL_COLORS[Math.min(order, LEVEL_COLORS.length) - 1] ?? LEVEL_COLORS[0]
}

// CSV fayl yuklab olish (ustoz natijalar eksporti)
export function downloadCsv(filename: string, rows: (string | number)[][]) {
  const csv = rows
    .map((row) =>
      row
        .map((cell) => {
          const s = String(cell ?? '')
          return s.includes(';') || s.includes('"') || s.includes('\n') ? `"${s.replace(/"/g, '""')}"` : s
        })
        .join(';')
    )
    .join('\n')
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = filename
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(link.href)
}
