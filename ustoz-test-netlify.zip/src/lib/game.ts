// Server tomonidagi o'yin mantiqiy yordamchilari
import { db } from '@/lib/db'

export interface SettingsValues {
  pointsPerCorrectGroup: number
  moneyPerCorrectGroup: number
  moneyPerCorrectIndividual: number
  totalModules: number
  modulesPerLevel: number
  avgPointsPerModule: number
}

export async function getSettings(): Promise<SettingsValues> {
  const rows = await db.setting.findMany()
  const map = new Map(rows.map((r) => [r.key, Number(r.value)]))
  return {
    pointsPerCorrectGroup: map.get('pointsPerCorrectGroup') ?? 10,
    moneyPerCorrectGroup: map.get('moneyPerCorrectGroup') ?? 5,
    moneyPerCorrectIndividual: map.get('moneyPerCorrectIndividual') ?? 3,
    totalModules: map.get('totalModules') ?? 30,
    modulesPerLevel: map.get('modulesPerLevel') ?? 5,
    avgPointsPerModule: map.get('avgPointsPerModule') ?? 60,
  }
}

export async function getLevels() {
  return db.level.findMany({ orderBy: { order: 'asc' } })
}

/**
 * Darajani tekshirish va oshirish:
 * Keyingi darajaga o'tish uchun (1) yetarli ball va (2) o'sha daraja uchun
 * belgilangan barcha shartli jihozlar sotib olingan bo'lishi kerak.
 * Bir necha daraja ketma-ket otsa ham hisobga olinadi.
 * Qaytaradi: { from, to } yoki null
 */
export async function checkLevelUp(userId: string): Promise<{ from: number; to: number } | null> {
  const user = await db.user.findUnique({ where: { id: userId } })
  if (!user || user.role !== 'STUDENT') return null

  const levels = await getLevels()
  const purchases = await db.purchase.findMany({ where: { userId } })
  const ownedItemIds = new Set(purchases.map((p) => p.itemId))
  const requiredItems = await db.shopItem.findMany({
    where: { requiredForLevel: { gt: 0 } },
  })

  let currentOrder = user.levelOrder
  let changed = false

  for (;;) {
    const next = levels.find((l) => l.order === currentOrder + 1)
    if (!next) break
    if (user.points < next.requiredPoints) break
    const requiredForNext = requiredItems.filter((i) => i.requiredForLevel === next.order)
    const allOwned = requiredForNext.every((i) => ownedItemIds.has(i.id))
    if (!allOwned) break
    currentOrder = next.order
    changed = true
  }

  if (changed) {
    await db.user.update({ where: { id: userId }, data: { levelOrder: currentOrder } })
    return { from: user.levelOrder, to: currentOrder }
  }
  return null
}

/**
 * Urinishni yakunlash: to'g'ri javoblarni hisoblab, mukofot beradi.
 * Guruh testi: ball + tanga. Individual test: faqat tanga.
 */
export async function finishAttempt(attemptId: string) {
  const attempt = await db.attempt.findUnique({
    where: { id: attemptId },
    include: { session: true, answers: true },
  })
  if (!attempt || attempt.status === 'FINISHED') return null

  const correct = attempt.answers.filter((a) => a.isCorrect).length
  const total = attempt.session.questionCount
  const isGroup = attempt.session.type === 'GROUP'
  const settings = await getSettings()

  const pointsEarned = isGroup ? correct * settings.pointsPerCorrectGroup : 0
  const moneyEarned = correct * (isGroup ? settings.moneyPerCorrectGroup : settings.moneyPerCorrectIndividual)

  const updated = await db.attempt.update({
    where: { id: attemptId },
    data: {
      status: 'FINISHED',
      score: correct,
      pointsEarned,
      moneyEarned,
      finishedAt: new Date(),
    },
  })

  await db.user.update({
    where: { id: attempt.userId },
    data: { money: { increment: moneyEarned }, points: { increment: pointsEarned } },
  })

  const levelUp = await checkLevelUp(attempt.userId)

  return { attempt: updated, correct, total, moneyEarned, pointsEarned, levelUp }
}
